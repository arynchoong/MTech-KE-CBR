/**
 * CaseBaseFilter.java
 * jCOLIBRI2 framework. 
 * @author Juan A. Recio-Garc�a.
 * GAIA - Group for Artificial Intelligence Applications
 * http://gaia.fdi.ucm.es
 * 03/01/2007
 */

package jcolibri.cbrcore;

/**
 * Filter to retrieve cases. This will be used in a future.
 * @author Juan A. Recio-Garc�a
 *
 */
public class CaseBaseFilter implements Filter
{

}
